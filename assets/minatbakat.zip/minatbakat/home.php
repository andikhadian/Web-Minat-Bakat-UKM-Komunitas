<?php 
session_start();
if(! isset($_SESSION['is_login']))
{
  header('location:login.php');
}
?>
  <!DOCTYPE html>
<html lang="en">

<head>
  <title>layanan Minat & Bakat FTI</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">


  <link href="https://fonts.googleapis.com/css?family=Muli:300,400,700,900" rel="stylesheet">
  <link rel="stylesheet" href="fonts/icomoon/style.css">

  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/jquery-ui.css">
  <link rel="stylesheet" href="css/owl.carousel.min.css">
  <link rel="stylesheet" href="css/owl.theme.default.min.css">
  <link rel="stylesheet" href="css/owl.theme.default.min.css">

  <link rel="stylesheet" href="css/jquery.fancybox.min.css">

  <link rel="stylesheet" href="css/bootstrap-datepicker.css">

  <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">

  <link rel="stylesheet" href="css/aos.css">

  <link rel="stylesheet" href="css/style.css">

</head>

<body data-spy="scroll" data-target=".site-navbar-target" data-offset="300">

  <div class="site-wrap">

    <div class="site-mobile-menu site-navbar-target">
      <div class="site-mobile-menu-header">
        <div class="site-mobile-menu-close mt-3">
          <span class="icon-close2 js-menu-toggle"></span>
        </div>
      </div>
      <div class="site-mobile-menu-body"></div>
    </div>


    <header class="site-navbar py-4 js-sticky-header site-navbar-target" role="banner">

      <div class="container-fluid">
        <div class="d-flex align-items-center">
          <div class="site-logo mr-auto w-25"><a href="home.php">Layanan Minat & Bakat FTI</a></div>
          <div class="mx-auto text-center">
            <nav class="site-navigation position-relative text-right" role="navigation">
              <ul class="site-menu main-menu js-clone-nav mx-auto d-none d-lg-block  m-0 p-0">
                <li><a href="#home-section" class="nav-link">Home</a></li>
                <li><a href="#courses-section" class="nav-link">Galeri</a></li>
                <li><a href="#programs-section" class="nav-link">Tentang</a></li>
                <li><a href="#teachers-section" class="nav-link">Struktur</a></li>
                <li><a href="#contact-section" class="nav-link">Kontak</a></li>
              </ul>
            </nav>
          </div>
          <div class="ml-auto w-25">
            <nav class="site-navigation position-relative text-right" role="navigation">
              <ul class="site-menu main-menu site-menu-dark js-clone-nav mr-auto d-none d-lg-block m-0 p-0">
                <li class="cta"><a href="logout.php" class="nav-link"><span>Logout</span></a></li>
              </ul>
            </nav>
            <a href="#" class="d-inline-block d-lg-none site-menu-toggle js-menu-toggle text-black float-right"><span
                class="icon-menu h3"></span></a>
          </div>
        </div>
      </div>
    </header>
    <div class="intro-section" id="home-section">
      <div class="slide-1" style="background-image: url('images/backround_1.jpg');" data-stellar-background-ratio="0.5">
        <div class="container">
          <div class="row align-items-center">
            <div class="col-12">
              <div class="row align-items-center">
                <div class="row mb-7 justify-content-center">
                  <div class="col-lg-8 text-center" data-aos="fade-up" data-aos-delay="">
                    <h2 class="section-title text-white">Layanan Minat & Bakat</h2>
                  </div>
                  <h5 class="text-white">
                    Selamat datang di Website Layanan Informasi Minat dan Bakat Fakultas Teknologi
                    Informasi
                    Universitas Respati Indonesia, Website ini akan menampilkan informasi mengenai Unit Kegiatan
                    Mahasiswa (UKM) dan Komunitas yang ada di Universitas Respati Indonesia sehingga dapat membantu
                    Mahasiswa untuk mencari Informasi mengenai UKM dan Komunitas apa saja yang ada di Universitas
                    Respati Indonesia. Universitas Respati Indonesia sebagai Universitas Enterpreneuship dan sebagai
                    Universitas ramah lansia.
                  </h5>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="site-section courses-title" id="courses-section">
      <div class="container">
        <div class="row mb-5 justify-content-center">
          <div class="col-lg-7 text-center" data-aos="fade-up" data-aos-delay="">
            <h2 class="section-title">Galeri Foto Kegiatan</h2>
          </div>
        </div>
      </div>
    </div>
    <div class="site-section courses-entry-wrap" data-aos="fade-up" data-aos-delay="100">
      <div class="container">
        <div class="row">
          <div class="owl-carousel col-12 nonloop-block-14">
            <!-- foto futsal -->
            <img src="images/futsal_10.jpg" width="250px" height="250px">
            <img src="images/futsal_11.jpg" width="250px" height="250px">
            <img src="images/futsal_3.jpg" width="250px" height="250px">
            <!-- /foto futsal -->

            <!-- foto mapares -->
            <img src="images/mapares_4.jpg" width="250px" height="250px">
            <img src="images/mapares_5.jpg" width="250px" height="250px">
            <img src="images/mapares1.jpg" width="250px" height="250px">
            <!-- /foto mapares -->

            <!-- foto pmk -->
            <img src="images/pmk_11.jpg" width="250px" height="250px">
            <img src="images/pmk_4.jpg" width="250px" height="250px">
            <img src="images/pmk_10.jpg" width="250px" height="250px">
            <!-- /foto pmk -->

            <!-- foto ldk -->
            <img src="images/ldk_4.jpg" width="250px" height="250px">
            <img src="images/ldk_5.jpg" width="250px" height="250px">
            <img src="images/ldk_9.jpg" width="250px" height="250px">
            <!-- /foto ldk -->

            <!-- foto taekwondo -->
            <img src="images/taekwondo_2.jpg" width="250px" height="250px">
            <img src="images/taekwondo_3.jpg" width="250px" height="250px">
            <img src="images/taekwondo_4.jpg" width="250px" height="250px">
            <!-- /foto taekwondo -->

            <!-- foto LPMU-->
            <img src="images/lpmu_3.jpg" width="250px" height="250px">
            <img src="images/lpmu_8.jpg" width="250px" height="250px">
            <img src="images/lpmu_11.jpg" width="250px" height="250px">
            <!-- /foto LPMU -->

            <!-- foto UMC -->
            <img src="images/umc_10.jpg" width="250px" height="250px">
            <img src="images/umc_6.jpg" width="250px" height="250px">
            <img src="images/umc_5.jpg" width="250px" height="250px">
            <!-- /foto UMC -->

            <!-- foto IOT -->
            <img src="images/iot_1.jpg" width="250px" height="250px">
            <img src="images/iot_2.jpg" width="250px" height="250px">
            <img src="images/iot_4.jpg" width="250px" height="250px">
            <!-- /foto IOT -->
          </div>
        </div>
        <div class="row justify-content-center">
          <div class="col-7 text-center">
            <button class="customPrevBtn btn btn-primary m-1">Sebelumnya</button>
            <button class="customNextBtn btn btn-primary m-1">Selanjutnya</button>
          </div>
        </div>
      </div>
    </div>
    <div class="site-section" id="programs-section">
      <div class="container">
        <div class="row mb-5 justify-content-center">
          <div class="col-lg-7 text-center" data-aos="fade-up" data-aos-delay="">
            <h2 class="section-title">Minat dan Bakat</h2>
            <p>Selain memiliki BEM, Universitas Respati Indonesia juga memiliki Unit Kegiatan Mahasiswa (UKM) dan
              beberapa
              Komunitas,
              UKM dan Komunitas merupakan club ekstrakulikuler sebagai wadah untuk mempelajari ataupun mengesplor bakat
              maupun minat yang
              dimiliki oleh mahasiswa!
            </p>
          </div>
        </div>
        <div class="row mb-5 align-items-center">
          <div class="col-lg-7 mb-5" data-aos="fade-up" data-aos-delay="100">
            <img src="images/perkenalan_1.jpg" alt="Image" class="img-fluid">
          </div>
          <div class="col-lg-4 ml-auto" data-aos="fade-up" data-aos-delay="200">
            <h2 class="text-black mb-4">Perkenalan</h2>
            <p class="mb-4">
            <p align="justify">Diawal menjadi Mahasiswa, akan diadakan UKM expo untuk memperkenalkan masing-masing UKM
              dan
              Komunitas ke
              mahasiswa agar bisa mengesplor minat dan bakat mereka serta perekrutan anggota baru untuk Mahasiswa yang
              ingin
              bergabung,
              Unit Kegiatan Mahasiswa atau dikenal (UKM) dan Komunitas sendiri adalah wadah aktivitas Mahasiswa luar
              kelas
              untuk
              mengembangkan minat, bakat dan keahlian tertentu.
            </p>
          </div>
        </div>
        <div class="row mb-5 align-items-center">
          <div class="col-lg-7 mb-5 order-1 order-lg-2" data-aos="fade-up" data-aos-delay="100">
            <img src="images/perkenalan_2.jpg" alt="Image" class="img-fluid">
          </div>
          <div class="col-lg-4 mr-auto order-2 order-lg-1" data-aos="fade-up" data-aos-delay="200">
            <p class="mb-4">
            <p align="justify">Mahasiswa yang telah resmi menjadi anggota dari masing-masing UKM dan Komunitas akan
              mendapatkan
              pelatihan
              dari UKM dan Komunitas
              tersebut, sehingga sangat memungkinkan untuk Mahasiswa yang belum mempunyai bakat khusus namun ingin
              bergabung.
              UKM dan Komunitas URINDO juga bisa dikatakan sebagai wadah untuk mempelajari ekstrakulikuler yang telah
              teredia, disini
              Mahasiswa
              juga akan mendapatkan pengalaman baru dan memiliki keluarga baru didunia perkuliahan.
            </p>
          </div>
        </div>

        <div class="row mb-5 align-items-center">
          <div class="col-lg-7 mb-5" data-aos="fade-up" data-aos-delay="100">
            <img src="images/perkenalan_3.jpg" alt="Image" class="img-fluid">
          </div>
          <div class="col-lg-4 ml-auto" data-aos="fade-up" data-aos-delay="200">
            <p class="mb-4">
            <p align="justify">Untuk itu sangat disarankan kepada teman-teman Mahasiswa agar dapat bergabung dengan UKM
              dan
              Komunitas yang ada di Universitas Respati Indonesia dan selalu mengasah bakat yang dimiliki.</p>
            </p>
          </div>
        </div>
      </div>
    </div>
    <div class="site-section" id="teachers-section">
      <div class="container">
        <div class="row mb-2 justify-content-center">
          <div class="col-lg-9 mb-5 text-center" data-aos="fade-up" data-aos-delay="">
            <h2 class="section-title">Struktur Organisasi Fakultas Teknologi Informasi</h2>
          </div>
        </div>
        <br>
        <br>
        <div class="row">
          <div class="col-md-6 col-lg-4 mb-4" data-aos="fade-up" data-aos-delay="100">
            <div class="teacher text-center">
              <img src="images/dosen_4.jpg" alt="Image" class="img-fluid w-52 rounded-circle mx-auto mb-4">
              <div class="py-2">
                <h3 class="text-black">Desmiwati, S.Kom, M.Si</h3>
                <p class="position">Dekan Fakultas Teknologi Informasi</p>
              </div>
            </div>
          </div>
          <div class="col-md-4 col-lg-4 mb-2" data-aos="fade-up" data-aos-delay="200">
            <div class="teacher text-center">
              <img src="images/dosen_2.jpg" alt="Image" class="img-fluid w-52 rounded-circle mx-auto mb-4">
              <div class="py-2">
                <h3 class="text-black">Andi Susilo, S.Kom, M.TI</h3>
                <p class="position">Ketua Program Studi Ilmu Komputer</p>
              </div>
            </div>
          </div>
          <div class="col-md-6 col-lg-4 mb-4" data-aos="fade-up" data-aos-delay="300">
            <div class="teacher text-center">
              <img src="images/dosen_3.jpg" alt="Image" class="img-fluid w-52 rounded-circle mx-auto mb-4">
              <div class="py-2">
                <h3 class="text-black">Ramadhani Ulansari S.Kom, MT</h3>
                <p class="position">Ketua Program Studi Sistem Informasi</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="site-section bg-image overlay" style="background-image: url('images/urindo_1.png');">
      <div class="container">
        <div class="row justify-content-center align-items-center">
          <div class="col-md-8 text-center testimony">
            <img src="images/kabag_1.jpg" alt="Image" class="img-fluid w-25 mb-4 rounded-circle">
            <h3 class="mb-4">Sugeng Hadi Saputra M.Kep Sp.An</h3>
            <blockquote>
              <p>&ldquo; Kabag Kemahasiswaan &rdquo;</p>
            </blockquote>
          </div>
        </div>
      </div>
    </div>

    <div class="site-section courses-title" id="courses-section">
      <div class="container">
        <div class="row mb-5 justify-content-center">
          <div class="col-lg-7 text-center" data-aos="fade-up" data-aos-delay="">
            <h2 class="section-title">Informasi Kegiatan Mahasiswa</h2>
          </div>
        </div>
      </div>
    </div>
    <div class="site-section courses-entry-wrap" data-aos="fade-up" data-aos-delay="100">
      <div class="container">
        <div class="album py-5 bg-light">
          <div class="container">
            <div class="row">

              <!--kotak taekwondo-->
              <div class="col-md-4">
                <div class="card mb-4 shadow-sm">
                  <img src="images/taekwondo_1.jpg" width="339" height="250">
                  <div class="card-body">
                    <p class="card-text"><strong>UKM Taekwondo</strong></p>
                    <div class="d-flex justify-content-between align-items-center">
                      <div class="btn-group">
                        <a href="ukm_taekwondo.html">
                          <button type="button" class="btn btn-sm btn-outline-secondary">Lihat</button>
                        </a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <!--kotak ldk-->
              <div class="col-md-4">
                <div class="card mb-4 shadow-sm">
                  <img src="images/ldk_2.jpg" height="250" width="339">
                  <div class="card-body">
                    <p class="card-text"><strong>UKM Lembaga Dakwah Mahasiswa</strong></p>
                    <div class="d-flex justify-content-between align-items-center">
                      <div class="btn-group">
                        <a href="ukm_ldk.html">
                          <button type="button" class="btn btn-sm btn-outline-secondary">Lihat</button>
                        </a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <!--kotak pmk-->
              <div class="col-md-4">
                <div class="card mb-4 shadow-sm">
                  <img src="images/pmk_1.jpg" width="339" height="250">
                  <div class="card-body">
                    <p class="card-text"><strong>UKM Persukutan Mahasiswa Kristen</strong></p>
                    <div class="d-flex justify-content-between align-items-center">
                      <a href="ukm_pmk.html">
                        <button type="button" class="btn btn-sm btn-outline-secondary">Lihat</button>
                      </a>
                    </div>
                  </div>
                </div>
              </div>

              <!--kotak LPMU-->
              <div class="col-md-4">
                <div class="card mb-4 shadow-sm">
                  <img src="images/lpmu_1.jpg" width="339" height="250">
                  <div class="card-body">
                    <p class="card-text"><strong>UKM Lembaga Pers Mahasiswa URINDO</strong></p>
                    <div class="d-flex justify-content-between align-items-center">
                      <a href="ukm_lpmu.html">
                        <button type="button" class="btn btn-sm btn-outline-secondary">Lihat</button>
                      </a>
                    </div>
                  </div>
                </div>
              </div>

              <!--kotak Mapares-->
              <div class="col-md-4">
                <div class="card mb-4 shadow-sm">
                  <img src="images/mapares_1.jpg" width="339" height="250">
                  <div class="card-body">
                    <p class="card-text"><strong>UKM Mahasiswa Pencinta Alam Respati</strong></p>
                    <div class="d-flex justify-content-between align-items-center">
                      <a href="mapares.html">
                        <button type="button" class="btn btn-sm btn-outline-secondary">Lihat</button>
                      </a>
                    </div>
                  </div>
                </div>
              </div>

              <!--kotak UMC-->
              <div class="col-md-4">
                <div class="card mb-4 shadow-sm">
                  <img src="images/umc_1.jpg" width="339" height="250">
                  <div class="card-body">
                    <p class="card-text"><strong>Komunitas Urindo Music Club</strong></p>
                    <div class="d-flex justify-content-between align-items-center">
                      <a href="komunitas_umc.html">
                        <button type="button" class="btn btn-sm btn-outline-secondary">Lihat</button>
                      </a>
                    </div>
                  </div>
                </div>
              </div>

              <!--kotak FUTSAL-->
              <div class="col-md-4">
                <div class="card mb-4 shadow-sm">
                  <img src="images/futsal_1.jpg" width="339" height="250">
                  <div class="card-body">
                    <p class="card-text"><strong>Komunitas Futsal URINDO</strong></p>
                    <div class="d-flex justify-content-between align-items-center">
                      <a href="komunitas_futsal.html">
                        <button type="button" class="btn btn-sm btn-outline-secondary">Lihat</button>
                      </a>
                    </div>
                  </div>
                </div>
              </div>


              <!--kotak IOT-->
              <div class="col-md-4">
                <div class="card mb-4 shadow-sm">
                  <img src="images/IOT1.jpg" width="339" height="250">
                  <div class="card-body">
                    <p class="card-text"><strong>IoT (Internet of Things) URINDO</strong></p>
                    <div class="d-flex justify-content-between align-items-center">
                      <a href="lab_iot.html">
                        <button type="button" class="btn btn-sm btn-outline-secondary">Lihat</button>
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>



    <div class="site-section pb-0">
      <div class="future-blobs">
        <div class="blob_2">
          <img src="images/blob_2.svg" alt="Image">
        </div>
        <div class="blob_1">
          <img src="images/blob_1.svg" alt="Image">
        </div>
      </div>
      <div class="container">
        <div class="row mb-5 justify-content-center" data-aos="fade-up" data-aos-delay="">
          <div class="col-lg-7 text-center">




          </div>
          <div class="col-lg-7 align-self-end" data-aos="fade-left" data-aos-delay="200">

          </div>
        </div>
      </div>
    </div>





    <div class="site-section bg-light" id="contact-section">
      <div class="container">
        <p>
          <iframe style="border: 0;"
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3965.599864728413!2d106.89846501432133!3d-6.316175963565635!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69f7928392814b%3A0x4062fc4a6fa4587!2sUniversitas+Respati+Indonesia+(Kampus+A)!5e0!3m2!1sid!2sid!4v1502294198094"
            width="1000" height="300" frameborder="0" allowfullscreen="allowfullscreen">
          </iframe>
        </p>



        <footer class="footer-section bg-white">
          <div class="container">
            <div class="row">
              <div class="col-md-4">
                <h3>Tentang Website Minat & Bakat</h3>
                <p>
                <p align="justify"> Website ini dibuat untuk membantu teman-teman Mahasiswa agar dengan mudah
                  mencari
                  informasi UKM dan Komunitas apa saja yang ada di Universitas Respati Indonesia, sehingga
                  teman-teman selalu mengasah bakat yang teman-teman miliki dan menambah pengalaman didunia
                  perkuliahan, tujuan website ini dibuat juga agar teman-teman bisa bergabung dengan UKM dan
                  Komunitas
                  yang ada di Universitas Respati Indonesia.
                </p>
              </div>

              <div class="col-md-4 ml-auto">
                <h3>Web Links</h3>
                <ul class="list-unstyled footer-links">
                  <li><a href="http://fti.urindo.ac.id/">Website Fti Urindo</a></li>
                  <li><a href="#">Layanan karrir</a></li>
                  <li><a href="#">Layanan E-Konsultasi</a></li>
                  <li><a href="#">Lab IOT</a></li>
                </ul>
              </div>

              <div class="col-md-2">
                <h3>Kontak Kami</h3>
                <ul class="list-unstyled footer-links">
                  <a href="https://www.instagram.com/fti_urindo/?hl=id">Instagram Fti </a></li>
                  <a href="https://mobile.facebook.com/Fakultas-Teknologi-Informasi-Urindo-101068351675582/">Facebook
                    Fti</a></li>
                  </form>
              </div>

            </div>

            <div class="row pt-5 mt-5 text-center">
              <div class="col-md-12">
                <div class="border-top pt-5">
                  <p>
                    <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                    Copyright &copy;
                    <script>document.write(new Date().getFullYear());</script> All rights reserved | This template is
                    made
                    with <i class="icon-heart" aria-hidden="true"></i> by <a href="https://colorlib.com"
                      target="_blank">Nur Asia Hayoto</a>
                    <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                  </p>
                </div>
              </div>

            </div>
          </div>
        </footer>



      </div> <!-- .site-wrap -->

      <script src="js/jquery-3.3.1.min.js"></script>
      <script src="js/jquery-migrate-3.0.1.min.js"></script>
      <script src="js/jquery-ui.js"></script>
      <script src="js/popper.min.js"></script>
      <script src="js/bootstrap.min.js"></script>
      <script src="js/owl.carousel.min.js"></script>
      <script src="js/jquery.stellar.min.js"></script>
      <script src="js/jquery.countdown.min.js"></script>
      <script src="js/bootstrap-datepicker.min.js"></script>
      <script src="js/jquery.easing.1.3.js"></script>
      <script src="js/aos.js"></script>
      <script src="js/jquery.fancybox.min.js"></script>
      <script src="js/jquery.sticky.js"></script>


      <script src="js/main.js"></script>

</body>


</main><!-- /.container -->
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
      <script>window.jQuery || document.write('<script src="/docs/4.3/assets/js/vendor/jquery-slim.min.js"><\/script>')</script><script src="/docs/4.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-xrRywqdh3PHs8keKZN+8zzc5TX0GRTLCcmivcbNJWm2rs5C8PRhcEn3czEjhAO9o" crossorigin="anonymous"></script></body>
</html>